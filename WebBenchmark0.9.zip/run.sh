#��/bin/bash
dotnet BeetleX.WebBenchmark.App.dll port=80